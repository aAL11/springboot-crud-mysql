package com.example.projet;


import com.example.projet.user.user;
import com.example.projet.user.userRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.Optional;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class userRepositoryTests {
    @Autowired private userRepository repo;



    @Test
    public void testListAll(){
        Iterable<user> users = repo.findAll();
        Assertions.assertThat(users).hasSizeGreaterThan(0);

        for (user user : users){
            System.out.println(user);
        }
    }

    @Test
    public void testUpdate(){
        Integer userId = 1;
        Optional<user> optionaluser = repo.findById(userId);

        user user = optionaluser.get();
        user.setPassword("hello2002");
        repo.save(user);

        user updateduser = repo.findById(userId).get();
        Assertions.assertThat(updateduser.getPassword()).isEqualTo("hello2002");

    }

    @Test
    public void testGet(){
        Integer userId = 2;
        Optional<user> optionaluser = repo.findById(userId);
        Assertions.assertThat(optionaluser).isPresent();
        System.out.println(optionaluser.get());
    }

    @Test
    public void testDelete(){
        Integer userId = 2;
        repo.deleteById(userId);

        Optional<user> optionaluser = repo.findById(userId);
        Assertions.assertThat(optionaluser).isNotPresent();
    }

}
