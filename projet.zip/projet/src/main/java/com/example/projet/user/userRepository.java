package com.example.projet.user;

import org.springframework.data.repository.CrudRepository;

public interface userRepository extends CrudRepository<user, Integer> {
    public Long countById(Integer id);
}
