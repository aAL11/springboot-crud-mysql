import { RequestRegistration } from './request-registration';

describe('RequestRegistration', () => {
  it('should create an instance', () => {
    expect(new RequestRegistration()).toBeTruthy();
  });
});
