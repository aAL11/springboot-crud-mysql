import { ResponseError } from './response-error';

describe('ResponseError', () => {
  it('should create an instance', () => {
    expect(new ResponseError()).toBeTruthy();
  });
});
