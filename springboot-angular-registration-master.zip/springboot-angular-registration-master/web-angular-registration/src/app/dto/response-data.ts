export class ResponseData {
    responseCode : string;
    responseMsg : string;
}
