import { ResponseData } from './response-data';

describe('ResponseData', () => {
  it('should create an instance', () => {
    expect(new ResponseData()).toBeTruthy();
  });
});
